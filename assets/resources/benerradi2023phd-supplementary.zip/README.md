# Index of supplementary materials

- `supplementary1_generalised_hyperparameters.csv`:
	
	Accuracy and hyperparameters of the subject-independent approach (Chapter 4) with the following columns:
	
	- *dataset*
	- *model*
	- *fold* (iteration number of the outer cross-validation)
	- *accuracy* (accuracy on the test set)
	- *hyperparameters* (regularisation for the SVC, value of k for the kNN, (batch size, learning rate) for the ANN, CNN and LSTM)


- `supplementary2_generalised_stats.md`:
	
	Result of the statistical tests for the subject-independent approach (Chapter 4):
	- first table presenting the significance of the difference of model accuracy to chance level with p-value of the Shapiro test (to verify the conditions of application of a parametric test), the resulting test used (parametric or non-parametric), its statistic and its p-value
	- second table presenting the significance of the influence of the model on the accuracy with the value of the Bartlett test (to verify the conditions of application of a parametric test), the resulting test used (parametric or non-parametric), its statistic and its p-value


- `supplementary3_sliding_hyperparameters.csv`:
	
	Accuracy and hyperparameters of the subject-independent approach with sliding window (Chapter 4) with the following columns:
	
	- *dataset*
	- *model*
	- *fold* (iteration number of the outer cross-validation)
	- *accuracy* (accuracy on the test set)
	- *hyperparameters* (regularisation for the SVC, value of k for the kNN, (batch size, learning rate) for the ANN)


- `supplementary4_sliding_stats.md`:
	
	Result of the statistical tests for the subject-independent approach with sliding window (Chapter 4):
	- first table presenting the significance of the difference of model accuracy to chance level with p-value of the Shapiro test (to verify the conditions of application of a parametric test), the resulting test used (parametric or non-parametric), its statistic and its p-value
	- second table presenting the significance of the influence of the model on the accuracy with the value of the Bartlett test (to verify the conditions of application of a parametric test), the resulting test used (parametric or non-parametric), its statistic and its p-value


- `supplementary5_personalised_stats.md`:
	
	Result of the statistical tests for the subject-specific approach (Chapter 4):
	- first table presenting for each participant the significance of the difference of model accuracy to chance level with p-value of the Shapiro test (to verify the conditions of application of a parametric test), the resulting test used (parametric or non-parametric) and its p-value
	- second table presenting for each participant the significance of the influence of the model on the accuracy with the value of the Bartlett test (to verify the conditions of application of a parametric test), the resulting test used (parametric or non-parametric) and its p-value


- `supplementary6_new_generalised_hyperparameters.csv`:
	
	Accuracy and hyperparameters of the subject-independent approach (Chapter 5) with the following columns:
	
	- *dataset*
	- *model*
	- *fold* (iteration number of the outer cross-validation)
	- *accuracy* (accuracy on the test set)
	- *hyperparameters* (regularisation for the SVC, value of k for the kNN, (batch size, learning rate) for the ANN, CNN and LSTM)


- `supplementary7_new_generalised_stats.md`:
	
	Result of the statistical tests for the new subject-independent approach (Chapter 5):
	- first table presenting the significance of the difference of model accuracy to chance level with p-value of the Shapiro test (to verify the conditions of application of a parametric test), the resulting test used (parametric or non-parametric), its statistic and its p-value
	- second table presenting the significance of the influence of the model on the accuracy with the value of the Bartlett test (to verify the conditions of application of a parametric test), the resulting test used (parametric or non-parametric), its statistic and its p-value
 

- `benchnirs-tailored-transfer.zip`:

    Full BenchNIRS code, including additions for n-back tailored models and transfer learning (Chapter 6)
